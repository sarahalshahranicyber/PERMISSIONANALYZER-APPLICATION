package com.example.permissionanalyzer

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppsAdapter(
    private var apps: List<AppInfo>,
    private val onItemClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppsAdapter.AppViewHolder>() {

    class AppViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val appNameTextView: TextView = itemView.findViewById(R.id.appNameTextView)
        val riskTextView: TextView = itemView.findViewById(R.id.riskTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return AppViewHolder(view)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        val app = apps[position]
        holder.appNameTextView.text = app.appName

        val risk = calculateRisk(app.permissions)
        holder.riskTextView.text = "Risk: $risk  |  Permissions: ${app.permissions.size}"

        when (risk) {
            "HIGH" -> holder.riskTextView.setTextColor(Color.RED)
            "MEDIUM" -> holder.riskTextView.setTextColor(Color.rgb(255, 165, 0)) // orange
            else -> holder.riskTextView.setTextColor(Color.GREEN)
        }

        holder.itemView.setOnClickListener { onItemClick(app) }
    }

    override fun getItemCount(): Int = apps.size

    fun updateList(newApps: List<AppInfo>) {
        apps = newApps
        notifyDataSetChanged()
    }

    // --- Risk logic ---
    private fun calculateRisk(perms: List<String>): String {
        val dangerousKeywords = listOf(
            "READ_SMS", "SEND_SMS", "RECEIVE_SMS",
            "READ_CONTACTS", "WRITE_CONTACTS",
            "RECORD_AUDIO", "CAMERA",
            "ACCESS_FINE_LOCATION", "ACCESS_COARSE_LOCATION",
            "READ_CALL_LOG", "WRITE_CALL_LOG", "CALL_PHONE",
            "READ_EXTERNAL_STORAGE", "WRITE_EXTERNAL_STORAGE"
        )

        val count = perms.count { p -> dangerousKeywords.any { key -> p.contains(key) } }

        return when {
            count >= 5 -> "HIGH"
            count in 2..4 -> "MEDIUM"
            else -> "LOW"
        }
    }
}