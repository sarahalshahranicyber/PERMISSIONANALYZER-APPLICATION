package com.example.permissionanalyzer

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        val appName = intent.getStringExtra("appName") ?: "Unknown"
        val packageName = intent.getStringExtra("packageName") ?: ""
        val permissions = intent.getStringArrayListExtra("permissions") ?: arrayListOf()

        val nameText: TextView = findViewById(R.id.detailsAppName)
        val pkgText: TextView = findViewById(R.id.detailsPackageName)
        val permText: TextView = findViewById(R.id.detailsPermissions)

        nameText.text = appName
        pkgText.text = packageName

        permText.text = if (permissions.isEmpty()) {
            "No permissions requested"
        } else {
            permissions.joinToString("\n")
        }
    }
}