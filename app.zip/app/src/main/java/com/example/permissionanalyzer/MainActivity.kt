package com.example.permissionanalyzer

import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AppsAdapter
    private lateinit var searchEditText: EditText
    private var appList = mutableListOf<AppInfo>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.appsRecyclerView)
        searchEditText = findViewById(R.id.searchEditText)

        adapter = AppsAdapter(appList) { app ->
            val intent = android.content.Intent(this, DetailsActivity::class.java)
            intent.putExtra("appName", app.appName)
            intent.putExtra("packageName", app.packageName)
            intent.putStringArrayListExtra("permissions", ArrayList(app.permissions))
            startActivity(intent)
        }
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        loadInstalledApps()
    }

    private fun loadInstalledApps() {
        val pm = packageManager

        val intent = android.content.Intent(android.content.Intent.ACTION_MAIN, null).apply {
            addCategory(android.content.Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos = pm.queryIntentActivities(intent, 0)

        appList.clear()

        for (ri in resolveInfos) {
            val appName = ri.loadLabel(pm)?.toString() ?: "Unknown"
            val packageName = ri.activityInfo.packageName

            val pkgInfo = pm.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
            val permissions = pkgInfo.requestedPermissions?.toList() ?: emptyList()

            appList.add(AppInfo(appName, packageName, permissions))
        }

        appList.sortBy { it.appName.lowercase() }
        adapter.updateList(appList)
    }
}